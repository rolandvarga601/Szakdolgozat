package backgroundTask;


import javax.inject.Inject;
import java.util.concurrent.TimeUnit;

import com.kuka.generated.ioAccess.GripperControlIOGroup;
import com.kuka.roboticsAPI.applicationModel.tasks.CycleBehavior;
import com.kuka.roboticsAPI.applicationModel.tasks.RoboticsAPICyclicBackgroundTask;
import com.kuka.roboticsAPI.conditionModel.BooleanIOCondition;
import com.kuka.roboticsAPI.conditionModel.ObserverManager;
import com.kuka.roboticsAPI.controllerModel.Controller;
import com.kuka.roboticsAPI.ioModel.AbstractIO;
import com.kuka.roboticsAPI.ioModel.Input;
import com.kuka.roboticsAPI.uiModel.AbstractApplicationUI;
import com.kuka.roboticsAPI.uiModel.IApplicationUI;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKey;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKeyBar;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKeyListener;
import com.kuka.roboticsAPI.uiModel.userKeys.UserKeyAlignment;
import com.kuka.roboticsAPI.uiModel.userKeys.UserKeyEvent;

/**
 * Implementation of a cyclic background task.
 * <p>
 * It provides the {@link RoboticsAPICyclicBackgroundTask#runCyclic} method 
 * which will be called cyclically with the specified period.<br>
 * Cycle period and initial delay can be set by calling 
 * {@link RoboticsAPICyclicBackgroundTask#initializeCyclic} method in the 
 * {@link RoboticsAPIBackgroundTask#initialize()} method of the inheriting 
 * class.<br>
 * The cyclic background task can be terminated via 
 * {@link RoboticsAPICyclicBackgroundTask#getCyclicFuture()#cancel()} method or 
 * stopping of the task.
 * @see UseRoboticsAPIContext
 * 
 */
public class UserKeys extends RoboticsAPICyclicBackgroundTask {

	@Inject
	private GripperControlIOGroup gripperControl;
	
	@Inject
	private ObserverManager observerManager;
	
	@Inject
	private IApplicationUI appui;
	
	@Override
	public void initialize() {
		// initialize your task here
		initializeCyclic(0, 500, TimeUnit.MILLISECONDS,
				CycleBehavior.BEST_EFFORT);
		IUserKeyBar gripperBar = appui.createUserKeyBar("Gripper");
		

		IUserKeyListener openListener = new IUserKeyListener() {
			@Override
			public void onKeyEvent(IUserKey key, UserKeyEvent event) {
			// Reaction to event
				gripperControl.setOpen(true);
				Input input = gripperControl.getInput("Status");
				BooleanIOCondition inputCondition =
				new BooleanIOCondition(input, true);
				boolean result = observerManager.
				waitFor(inputCondition, 5, TimeUnit.SECONDS);
				gripperControl.setOpen(false);
				
			}
			};
			
			IUserKeyListener closeListener = new IUserKeyListener() {
				@Override
				public void onKeyEvent(IUserKey key, UserKeyEvent event) {
				// Reaction to event
					gripperControl.setClose(true);
					Input input = gripperControl.getInput("Status");
					BooleanIOCondition inputCondition =
					new BooleanIOCondition(input, true);
					boolean result = observerManager.
					waitFor(inputCondition, 5, TimeUnit.SECONDS);
					gripperControl.setClose(false);
					
					
			}
			};
			
			IUserKeyListener zeroListener = new IUserKeyListener() {
				@Override
				public void onKeyEvent(IUserKey key, UserKeyEvent event) {
				// Reaction to event
					gripperControl.setOpen(false);
					gripperControl.setClose(false);
					
				}
				};
				
			
		
		
		IUserKey closeKey = gripperBar.addUserKey(1, closeListener, false);
		IUserKey openKey = gripperBar.addUserKey(2, openListener, false);
		IUserKey zeroKey = gripperBar.addUserKey(3, zeroListener, false);
		closeKey.setText(UserKeyAlignment.MIDDLE, "close");
		openKey.setText(UserKeyAlignment.MIDDLE, "open");
		zeroKey.setText(UserKeyAlignment.MIDDLE, "zero");
		gripperBar.publish();
	}

	@Override
	public void runCyclic() {
		// your task execution starts here
	}
}