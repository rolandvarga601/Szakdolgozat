package com.kuka.generated.ioAccess;

import javax.inject.Inject;
import javax.inject.Singleton;

import com.kuka.roboticsAPI.controllerModel.IRequestService;
import com.kuka.roboticsAPI.ioModel.AbstractIOGroup;
import com.kuka.roboticsAPI.ioModel.IOTypes;

/**
 * Automatically generated class to abstract I/O access to I/O group <b>GripperControl</b>.<br>
 * <i>Please, do not modify!</i>
 * <p>
 * <b>I/O group description:</b><br>
 * ./.
 */
@Singleton
public class GripperControlIOGroup extends AbstractIOGroup
{
	/**
	 * Constructor to create an instance of class 'GripperControl'.<br>
	 * <i>This constructor is automatically generated. Please, do not modify!</i>
	 *
	 * @param requestService
	 *            request service of controller, which has access to the I/O group 'GripperControl'
	 */
	@Inject
	public GripperControlIOGroup(IRequestService requestService)
	{
		super(requestService, "GripperControl");

		addDigitalOutput("Close", IOTypes.BOOLEAN, 1);
		addDigitalOutput("Open", IOTypes.BOOLEAN, 1);
		addInput("Status", IOTypes.BOOLEAN, 1);
	}

	/**
	 * Gets the value of the <b>digital output '<i>Close</i>'</b>.<br>
	 * <i>This method is automatically generated. Please, do not modify!</i>
	 * <p>
	 * <b>I/O direction and type:</b><br>
	 * digital output
	 * <p>
	 * <b>User description of the I/O:</b><br>
	 * ./.
	 * <p>
	 * <b>Range of the I/O value:</b><br>
	 * [false; true]
	 *
	 * @return current value of the digital output 'Close'
	 */
	public boolean getClose()
	{
		return getBooleanIOValue("Close", true);
	}

	/**
	 * Sets the value of the <b>digital output '<i>Close</i>'</b>.<br>
	 * <i>This method is automatically generated. Please, do not modify!</i>
	 * <p>
	 * <b>I/O direction and type:</b><br>
	 * digital output
	 * <p>
	 * <b>User description of the I/O:</b><br>
	 * ./.
	 * <p>
	 * <b>Range of the I/O value:</b><br>
	 * [false; true]
	 *
	 * @param value
	 *            the value, which has to be written to the digital output 'Close'
	 */
	public void setClose(java.lang.Boolean value)
	{
		setDigitalOutput("Close", value);
	}

	/**
	 * Gets the value of the <b>digital output '<i>Open</i>'</b>.<br>
	 * <i>This method is automatically generated. Please, do not modify!</i>
	 * <p>
	 * <b>I/O direction and type:</b><br>
	 * digital output
	 * <p>
	 * <b>User description of the I/O:</b><br>
	 * ./.
	 * <p>
	 * <b>Range of the I/O value:</b><br>
	 * [false; true]
	 *
	 * @return current value of the digital output 'Open'
	 */
	public boolean getOpen()
	{
		return getBooleanIOValue("Open", true);
	}

	/**
	 * Sets the value of the <b>digital output '<i>Open</i>'</b>.<br>
	 * <i>This method is automatically generated. Please, do not modify!</i>
	 * <p>
	 * <b>I/O direction and type:</b><br>
	 * digital output
	 * <p>
	 * <b>User description of the I/O:</b><br>
	 * ./.
	 * <p>
	 * <b>Range of the I/O value:</b><br>
	 * [false; true]
	 *
	 * @param value
	 *            the value, which has to be written to the digital output 'Open'
	 */
	public void setOpen(java.lang.Boolean value)
	{
		setDigitalOutput("Open", value);
	}

	/**
	 * Gets the value of the <b>digital input '<i>Status</i>'</b>.<br>
	 * <i>This method is automatically generated. Please, do not modify!</i>
	 * <p>
	 * <b>I/O direction and type:</b><br>
	 * digital input
	 * <p>
	 * <b>User description of the I/O:</b><br>
	 * ./.
	 * <p>
	 * <b>Range of the I/O value:</b><br>
	 * [false; true]
	 *
	 * @return current value of the digital input 'Status'
	 */
	public boolean getStatus()
	{
		return getBooleanIOValue("Status", false);
	}

}
