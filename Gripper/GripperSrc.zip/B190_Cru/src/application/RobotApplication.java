package application;


import javax.inject.Inject;

import com.kuka.generated.ioAccess.GripperControlIOGroup;
import com.kuka.geometry.ObjectFrame;
import com.kuka.geometry.SpatialObject;
import com.kuka.geometry.World;
import com.kuka.roboticsAPI.applicationModel.RoboticsAPIApplication;
import com.kuka.roboticsAPI.applicationModel.tasks.*;
import com.kuka.roboticsAPI.conditionModel.BooleanIOCondition;
import com.kuka.roboticsAPI.conditionModel.ObserverManager;

import static com.kuka.roboticsAPI.motionModel.BasicMotions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.kuka.roboticsAPI.deviceModel.LBR;
import com.kuka.roboticsAPI.ioModel.Input;

/**
 * Implementation of a robot application.
 * <p>
 * The application provides an {@link #initialize()} and a 
 * {@link #run()} method, which will be called successively in 
 * the application life cycle. The application will terminate automatically after 
 * the {@link #run()} method has finished or after stopping the 
 * task. The {@link #dispose()} method will be called, even if an 
 * exception is thrown during initialization or run. 
 * <p>
 * @see IRoboticsAPITaskInjectableTypes Types and Services available for Dependency Injection
 * @see RoboticsAPIApplication Application specific services available for Dependency Injection
 */
public class RobotApplication extends RoboticsAPIApplication {
	@Inject
	private LBR lBR_iiwa_14_R820_1;
	@Inject
	private World _world;
	@Inject
	private GripperControlIOGroup gripperControl;
	@Inject
	private ObserverManager observerManager;
	SpatialObject column1;


	@Override
	public void initialize() throws Exception {
		// initialize your application here
		column1 = _world.findObject("/Column1");

	}

	@Override
	public void run() throws Exception {
		

			OpenGripper();
		lBR_iiwa_14_R820_1.getFlange().move(ptp(column1.findFrame("/TopOfColumn/Approach")));
		lBR_iiwa_14_R820_1.getFlange().move(lin(column1.findFrame("/TopOfColumn")));
		CloseGripper();
		lBR_iiwa_14_R820_1.getFlange().move(lin(column1.findFrame("/TopOfColumn/Leave")));
		
		lBR_iiwa_14_R820_1.getFlange().move(ptp(_world.findFrame("/Showoff1")));
		lBR_iiwa_14_R820_1.getFlange().move(ptp(_world.findFrame("/Showoff2")));
		
		lBR_iiwa_14_R820_1.getFlange().move(ptp(column1.findFrame("/TopOfColumn/Leave")));
		//lBR_iiwa_14_R820_1.getFlange().move(lin(column1.findFrame("/TopOfColumn")));
		OpenGripper();
		lBR_iiwa_14_R820_1.getFlange().move(lin(column1.findFrame("/TopOfColumn/Approach")));
		lBR_iiwa_14_R820_1.getFlange().move(ptp(_world.findFrame("/Start")));

	}
	
	private void OpenGripper() {
		gripperControl.setOpen(true);
		wait(100);
		Input input = gripperControl.getInput("Status");
		BooleanIOCondition inputCondition =
		new BooleanIOCondition(input, true);
		boolean result = observerManager.
		waitFor(inputCondition, 5, TimeUnit.SECONDS);
		gripperControl.setOpen(false);
		
	}
	
	private void CloseGripper() {
		gripperControl.setClose(true);
		Input input = gripperControl.getInput("Status");
		wait(100);
		BooleanIOCondition inputCondition =
		new BooleanIOCondition(input, true);
		boolean result = observerManager.
		waitFor(inputCondition, 5, TimeUnit.SECONDS);
		gripperControl.setClose(false);
		
	}
	
	private void wait(int millisec) {
		try {
			Thread.sleep(millisec);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}