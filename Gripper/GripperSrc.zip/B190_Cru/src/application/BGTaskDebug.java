package application;


import javax.inject.Inject;

import com.kuka.generated.ioAccess.GripperControlIOGroup;
import com.kuka.roboticsAPI.applicationModel.RoboticsAPIApplication;
import com.kuka.roboticsAPI.applicationModel.tasks.*;
import com.kuka.roboticsAPI.conditionModel.BooleanIOCondition;
import com.kuka.roboticsAPI.conditionModel.ObserverManager;

import static com.kuka.roboticsAPI.motionModel.BasicMotions.*;

import java.util.concurrent.TimeUnit;

import com.kuka.roboticsAPI.deviceModel.LBR;
import com.kuka.roboticsAPI.ioModel.Input;
import com.kuka.roboticsAPI.uiModel.IApplicationUI;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKey;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKeyBar;
import com.kuka.roboticsAPI.uiModel.userKeys.IUserKeyListener;
import com.kuka.roboticsAPI.uiModel.userKeys.UserKeyAlignment;
import com.kuka.roboticsAPI.uiModel.userKeys.UserKeyEvent;

/**
 * Implementation of a robot application.
 * <p>
 * The application provides an {@link #initialize()} and a 
 * {@link #run()} method, which will be called successively in 
 * the application life cycle. The application will terminate automatically after 
 * the {@link #run()} method has finished or after stopping the 
 * task. The {@link #dispose()} method will be called, even if an 
 * exception is thrown during initialization or run. 
 * <p>
 * @see IRoboticsAPITaskInjectableTypes Types and Services available for Dependency Injection
 * @see RoboticsAPIApplication Application specific services available for Dependency Injection
 */
public class BGTaskDebug extends RoboticsAPIApplication {
	
	@Inject
	private ObserverManager observerManager;
	
	@Inject
	private GripperControlIOGroup gripperControl;
	
	@Inject
	private IApplicationUI appui;
	
	@Override
	public void initialize() throws Exception {
		// initialize your application here
IUserKeyBar gripperBar = appui.createUserKeyBar("Gripper");
		

		IUserKeyListener openListener = new IUserKeyListener() {
			@Override
			public void onKeyEvent(IUserKey key, UserKeyEvent event) {
			// Reaction to event
				gripperControl.setOpen(true);
				Input input = gripperControl.getInput("Status");
				BooleanIOCondition inputCondition =
				new BooleanIOCondition(input, true);
				boolean result = observerManager.
				waitFor(inputCondition, 5, TimeUnit.SECONDS);
				gripperControl.setOpen(false);
				
			}
			};
			
			IUserKeyListener closeListener = new IUserKeyListener() {
				@Override
				public void onKeyEvent(IUserKey key, UserKeyEvent event) {
				// Reaction to event
					gripperControl.setClose(true);
					Input input = gripperControl.getInput("Status");
					BooleanIOCondition inputCondition =
					new BooleanIOCondition(input, true);
					boolean result = observerManager.
					waitFor(inputCondition, 5, TimeUnit.SECONDS);
					gripperControl.setClose(false);
					
					
			}
			};
			
			IUserKeyListener zeroListener = new IUserKeyListener() {
				@Override
				public void onKeyEvent(IUserKey key, UserKeyEvent event) {
				// Reaction to event
					gripperControl.setOpen(false);
					gripperControl.setClose(false);
					
				}
				};
				
			
		
		
		IUserKey closeKey = gripperBar.addUserKey(1, closeListener, false);
		IUserKey openKey = gripperBar.addUserKey(2, openListener, false);
		IUserKey zeroKey = gripperBar.addUserKey(3, zeroListener, false);
		closeKey.setText(UserKeyAlignment.MIDDLE, "close");
		openKey.setText(UserKeyAlignment.MIDDLE, "open");
		zeroKey.setText(UserKeyAlignment.MIDDLE, "zero");
		gripperBar.publish();
	}

	@Override
	public void run() throws Exception {
		// your application execution starts here
		System.out.println("startWaiting");
		Thread.sleep(5000);
		System.out.println("stopWaiting");
	}
}