package application;


import javax.inject.Inject;

import com.kuka.generated.ioAccess.GripperControlIOGroup;
import com.kuka.roboticsAPI.applicationModel.RoboticsAPIApplication;
import com.kuka.roboticsAPI.applicationModel.tasks.*;
import com.kuka.roboticsAPI.conditionModel.BooleanIOCondition;
import com.kuka.roboticsAPI.conditionModel.ObserverManager;

import static com.kuka.roboticsAPI.motionModel.BasicMotions.*;

import java.util.concurrent.TimeUnit;

import com.kuka.roboticsAPI.deviceModel.LBR;
import com.kuka.roboticsAPI.ioModel.Input;

/**
 * Implementation of a robot application.
 * <p>
 * The application provides an {@link #initialize()} and a 
 * {@link #run()} method, which will be called successively in 
 * the application life cycle. The application will terminate automatically after 
 * the {@link #run()} method has finished or after stopping the 
 * task. The {@link #dispose()} method will be called, even if an 
 * exception is thrown during initialization or run. 
 * <p>
 * @see IRoboticsAPITaskInjectableTypes Types and Services available for Dependency Injection
 * @see RoboticsAPIApplication Application specific services available for Dependency Injection
 */
public class OpenThenCloseGripper extends RoboticsAPIApplication {
	@Inject
	private GripperControlIOGroup gripperControl;
	
	@Inject
	private ObserverManager observerManager;
	
	@Override
	public void initialize() throws Exception {
		// initialize your application here
	}

	@Override
	public void run() throws Exception {
		// your application execution starts here
		gripperControl.setOpen(true);
		Input input = gripperControl.getInput("Status");
		BooleanIOCondition inputCondition =
		new BooleanIOCondition(input, true);
		boolean result = observerManager.
		waitFor(inputCondition, 5, TimeUnit.SECONDS);
		gripperControl.setOpen(false);
		
		Thread.sleep(3000);
		
		gripperControl.setClose(true);
		Input input2 = gripperControl.getInput("Status");
		BooleanIOCondition inputCondition2 =
		new BooleanIOCondition(input2, true);
		boolean result2 = observerManager.
		waitFor(inputCondition2, 5, TimeUnit.SECONDS);
		gripperControl.setClose(false);
	}
}